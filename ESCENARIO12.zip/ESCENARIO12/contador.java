import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class contador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class contador extends Actor
{
      int cont;
      int s;
    static int limite;
    /**
     * Act - do whatever the contador wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        Inicializa();
        aumentaCont(cont);
        LlegoAlLimite();
    }
    public void Inicializa(){
        cont=0;
        limite=0;
    }
    public void aumentaCont(int n){
        if(cont==0){
            limite=0;
        }
        cont=n+1;
    }
    public void LlegoAlLimite(){
        if(cont==7){
            limite=1;
            cont=0;
        }
    }
    public void tamano(){
         GreenfootImage myImage = getImage();
        myImage.scale(5,10);
    }
}
