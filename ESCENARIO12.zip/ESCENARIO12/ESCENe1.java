import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ESCENe1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ESCENe1 extends World
{

    /**
     * Constructor for objects of class ESCENe1.
     * 
     */
    public ESCENe1()
    {    
        super(800, 450, 1);
        int dirY=310; 
        int dirX=25;
        int tamx=225;
        int tamy=10;
        addPlataform(dirY,dirX,tamx,tamy);
        dirX=418;
        tamx=290;
        addPlataform(dirY,dirX,tamx,tamy);
        addProta();
        addVolador();
        addAchero();
        //addAlienD();
        //addMono();
    }
    
    private void addProta(){
    prota prota= new prota();
    addObject(prota,45,150);
    prota.setLocation(45,265);
    prota.tamano();
    
    
    
   }
   private void addVolador(){
    enemigo enemigo1= new enemigo();
    addObject(enemigo1,38,150);
    enemigo1.setLocation(700,265);
    enemigo1.tamano();
   }
   //añadi al achero al escenario
    private void addAchero(){
    achero enemigo2= new achero();
    addObject(enemigo2,300,250);
    enemigo2.setLocation(300,250);
    enemigo2.tamano();
   }
   
   private void addAlienD(){
    alienD enemigo3= new alienD();
    addObject(enemigo3,400,250);
    enemigo3.setLocation(400,250);
    enemigo3.tamano();
   }
   
   private void addPlataform(int y, int x,int tamx,int tamy){
    Plataform p1= new Plataform();
    addObject(p1,x,y);
    p1.setLocation(x,y);
    p1.tamano(tamx,tamy);
   }
   
   private void addMono(){
       AlienM enemigo4= new AlienM();
    addObject(enemigo4,400,250);
    enemigo4.setLocation(330,250);
    enemigo4.tamano();
   }
}
