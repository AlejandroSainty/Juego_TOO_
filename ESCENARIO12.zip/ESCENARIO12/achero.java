import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class achero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class achero extends Actor
{
    /**
     * Act - do whatever the achero wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public int disparosRecibidos = 0;
    int altura=250;
    int EnemyY=170;
    int hlanzada=0;//nuevo
    int  protaX;
   int protaY;
   int Xactual=300;//nuevo
   int cambio=0;//nuevo
   int direction=1;
    
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(155,180);
    }
    public void tamano2() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(185,200);
    }
    public void remove(){ // este metodo eliina al objeto de el mundo
        getWorld().removeObject(this);
    }
    public void act()
    {

            /*if(c.limite==1){
                  setImage("hacero-inv.png");
                   tamano();
                  hacha hacha1 = new hacha();
            hacha1.tamano();
            hacha1.dano();
            getWorld().addObject(hacha1, getX()+50, getY()-15);
            }*/
        tamano();// Add your action code here.
        movimiento();
        cambioDireccion();
        comportamiento();
        if(atWorldEdge())
        {
            move(-1);
        }
        Actor balaContact = getOneIntersectingObject(Bala.class); // confirma si hubo contacto con un objeto de la clase bala
        // con el if preguntamos si hubo contacto y en caso de que si entra al if
        if(balaContact!=null){
            Bala balas = (Bala) getWorld().getObjects(Bala.class).get(0);

            disparosRecibidos = disparosRecibidos+balas.dano();
            getWorld().removeObject(balaContact); // al hacer contacto se remueve la bala de el escenario
             // el contador de disparos recibidos aumenta  
            if(disparosRecibidos==10){ // si los disparos recibidos son 3 entonces removemos el enemigo 
            getWorld().removeObject(this);
            }
            }
    }
    

    public void cambioDireccion(){
        //cambia el comportamiento del achero si llega al limete de la barra
         if(Xactual==300)
        {
            direction=1;//avanza derecha
           setImage("hacehro_correindo.png");
           tamano();
        setLocation(getX()+1,altura);
             //setImage("aCHERO.png");
        }
        
        if(Xactual==500){
            direction=-1;//leag al borde de la barra ahora a la izquierda
            //setLocation(getX()-1,altura);
             setImage("acherocorriendo2.png");
             tamano();
             setLocation(getX()-1,altura);
              
        }
        
        
        Xactual=getX();//actualizamos la x
    }
      public void movimiento(){//nuevo
          move(direction);
          
      }
      public void comportamiento(){
            int numero=Greenfoot.getRandomNumber(100);
            
            if(numero==13&&direction==-1){
                hlanzada=hlanzada+1;
                if(hlanzada==3){
                    setImage("hacero-inv.png");
                   tamano();
                    setImage("acherocorriendo2.png");
                  tamano();
                  hacha hacha1 = new hacha();
            hacha1.tamano();
            hacha1.dano();
            getWorld().addObject(hacha1, getX()+50, getY()-15);
            hlanzada=0;
            //setImage("acherocorriendo2.png");
              //     tamano();
                }
                 
               
            }
        
            

      }
      
    
    public boolean atWorldEdge()
             
    {  
        if(getX() < 10 || getX() > getWorld().getWidth() - 20)  
            return true;  
        if(getY() < 10 || getY() > getWorld().getHeight() - 20)  
            return true;  
        else 
            return false;  
    } 
    
}
