import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AlienM here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AlienM extends Actor
{
     public int disparosRecibidos = 0;
    int altura=250;
    int EnemyY=170;
    int hlanzada=0;//nuevo
    int  protaX;
   int protaY;
   int Xactual=600;//nuevo
   int cambio=0;//nuevo
   int direction=1;
    
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(140,140);
    }
    
    public void remove(){ // este metodo eliina al objeto de el mundo
        getWorld().removeObject(this);
    }
    public void act()
    {

        tamano();// Add your action code here.
        comportamiento();
        if(atWorldEdge())
        {
            move(-1);
        }
        Actor balaContact = getOneIntersectingObject(Bala.class); // confirma si hubo contacto con un objeto de la clase bala
        // con el if preguntamos si hubo contacto y en caso de que si entra al if
        if(balaContact!=null){
            Bala balas = (Bala) getWorld().getObjects(Bala.class).get(0);

            disparosRecibidos = disparosRecibidos+balas.dano();
            getWorld().removeObject(balaContact); // al hacer contacto se remueve la bala de el escenario
             // el contador de disparos recibidos aumenta  
            if(disparosRecibidos==4){ // si los disparos recibidos son 3 entonces removemos el enemigo 
            getWorld().removeObject(this);
            }
            }
    }
    

   
      public void comportamiento(){
            int numero=Greenfoot.getRandomNumber(100);
            move(-4);
            
                        if(numero>20&&numero<25){
                            move(4);
                        }

                        /*if(numero>40&&numero<60){
                            move(-4);
                        }*/
                        if(numero==80){
                            setImage("alienD2.png");
                            tamano();
                           
                        }
                        
                    
                        if(numero>80){
                           
                         setImage("alie_rapid_inv.png");
                         tamano();
                        }

      }
      
    
    public boolean atWorldEdge()
             
    {  
        if(getX() < 10 || getX() > getWorld().getWidth() - 20)  
            return true;  
        if(getY() < 10 || getY() > getWorld().getHeight() - 20)  
            return true;  
        else 
            return false;  
    } 
}
