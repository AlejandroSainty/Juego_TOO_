import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class balaD here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class balaD extends Actor
{
   private int velocidad = 15;
 
     public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(15,10);
        
    }
     public void direccion(){

        velocidad=-4;
        
    }
    public void act()
    {
         tamano();
        setLocation(getX()-velocidad, getY() );// Add your action code here.
        
        if (getX() > 795||getX() < 1) {
            getWorld().removeObject(this);
        }
    }
}
