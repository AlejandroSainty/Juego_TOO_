import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BalaE here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BalaE extends balaD
{
    private int velocidad = 15;
 
     public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(12,7);
        
    }
     public void direccion(){

        velocidad=-6;
        
    }
    public void act()
    {
         tamano();
        setLocation(getX()-velocidad, getY() );// Add your action code here.
        
        if (getX() > 795||getX() < 1) {
            getWorld().removeObject(this);
        }
    }
}
