import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bala here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bala extends Actor
{
    private int velocidad = 10;
    private int danoInicial =1;
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(10,10);
    }
    public void direccion(){
        velocidad=-10;
        
    }
    public void remove(){
        getWorld().removeObject(this);
    }
    public int dano(){
        int dano= danoInicial;
        return dano;
    }
    public void act()
    {
        tamano();
        setLocation(getX()+velocidad, getY() );// Add your action code here.
        if (getX() > 795||getX() < 1) {
            remove();
        }
    }
}
