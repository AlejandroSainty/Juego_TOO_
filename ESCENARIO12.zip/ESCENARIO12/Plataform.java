import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class plataform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Plataform extends Actor
{
        public void tamano(int x,int y) // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(x,y);
    }
    public void act()
    {
        // Add your action code here.
    }
}
