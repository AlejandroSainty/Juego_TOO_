import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class enemigo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemigo extends Actor
{

    public int disparosRecibidos = 0;
    int altura=150;
    int EnemyY=170;
    int  protaX;
   int protaY;
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(120,120);
    }
    public void remove(){ // este metodo eliina al objeto de el mundo
        getWorld().removeObject(this);
    }
    public void act()
    {
       
        tamano();// Add your action code here.
        probabilidad();
        if(atWorldEdge())
        {
            move(1);
        }
        Actor balaContact = getOneIntersectingObject(Bala.class); // confirma si hubo contacto con un objeto de la clase bala
        // con el if preguntamos si hubo contacto y en caso de que si entra al if
        if(balaContact!=null){
            Bala balas = (Bala) getWorld().getObjects(Bala.class).get(0);

            disparosRecibidos = disparosRecibidos+balas.dano();
            getWorld().removeObject(balaContact); // al hacer contacto se remueve la bala de el escenario
             // el contador de disparos recibidos aumenta  
            if(disparosRecibidos==3){ // si los disparos recibidos son 3 entonces removemos el enemigo 
            getWorld().removeObject(this);
            }
            }
    }
    
    public void probabilidad()
    {
        int numero=Greenfoot.getRandomNumber(100);

        if(numero<10)
        {
            move(4);
        }
        if(numero>20&&numero<30)
        {
            move(-6);
        
        }
        if(numero>30&&numero<50)
        {
           altura=altura-2;
        }
         if(numero>50&&numero<70)
        {
           altura=altura+2;
        }
        if(numero==70)
        {
        
            balaV bala = new balaV();
            bala.tamano();
            //bala.setRotation(90);
            getWorld().addObject(bala, getX()-50, getY()-15);
        
            
            
        }
        
        setLocation(getX(),altura);

    }
    
    public boolean atWorldEdge()
             
    {  
        if(getX() < 10 || getX() > getWorld().getWidth() - 20)  
            return true;  
        if(getY() < 10 || getY() > getWorld().getHeight() - 20)  
            return true;  
        else 
            return false;  
    } 
    

}