import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class balaV here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class balaV extends Actor
{
    /**
     * Act - do whatever the balaV wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int velocidad = 15;
    int xp=60;
    int yp=265;
     public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(40,20);
        
    }
     public void direccion(){

        velocidad=-6;
        xp=prota.posX;
        yp=prota.posY;
        
    }
    public void act()
    {
         tamano();
         int x=getX();
         int y=getY();
         int dx = xp-x;
         int dy=yp-y;
        setLocation(getX()-velocidad, getY()+4 );// Add your action code here.
        
        if (getX() > 795||getX() < 1) {
            getWorld().removeObject(this);
        }
    }
}
