import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class prota here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class prota extends Actor
{
    /**
     * Act - do whatever the prota wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    static int posX=25;
    static int posY=265;
    float vida;
    int velocidadx;
    int velocidady;
    int y_ref=265; // referencia de la plataforma principal
    private int numSaltos=0; // inicializamos el contador de saltos
    private int salto=90; // pixeles de el salto en eje y
    private boolean teclaPresionada = false; // nos ayuda a saber si una tecla ha sido presionada 
    private boolean teclaPresionada_bala = false; // lo de arriba x2 
    public void Cordenadas(){
        posX=getX();
        posY=getY();
    }
      public prota() // creamos un constructor para asignar las velocidades de nuestro prota a travez de el mundo 
    {
       velocidadx=3; // velocidad de moviminto 
       velocidady=3;// velocidad de caida
    }
    
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(120,80);
    }
    
    public void gravedad(){ // hace que niestro protagonista caiga
        //if(getY() < y_ref)
      setLocation(getX(),getY()+velocidady);
    }
       
   
    
    
    public void EventoTeclado(){
    if(Greenfoot.isKeyDown("left")){
          setLocation(getX()-velocidadx,getY());
          setImage("prota_correr_izquierda.png");// Actualiza la imagen del personaje
          if(Greenfoot.isKeyDown("space")&&!teclaPresionada_bala)
        {
            Bala bala = new Bala();
            bala.tamano();
            bala.dano();
            bala.direccion();
            getWorld().addObject(bala, getX()-50, getY()-15);
            teclaPresionada_bala = true;
        }
        }
        else{
            setImage("sPROL_IN2_PROTA.png");
        }
    if(Greenfoot.isKeyDown("right")){
        setLocation(getX()+velocidadx,getY()); 
        setImage("prota_correr_derecha.png");// Actualiza la imagen del personaje
        }
    if (Greenfoot.isKeyDown("space")&&!teclaPresionada_bala) {
            Bala bala = new Bala();
            bala.tamano();
            bala.dano();
            setImage("prota_correr_derecha.png");
            getWorld().addObject(bala, getX()+50, getY()-15);
            teclaPresionada_bala = true;

        }
      
    if (Greenfoot.isKeyDown("up") && !teclaPresionada && numSaltos < 2) {
            setLocation(getX(), getY()-salto);
            numSaltos++;
            teclaPresionada = true;
        }
        
    if (!Greenfoot.isKeyDown("up")) { // pregunta si la tecla up esta levantada
            teclaPresionada = false;
        }      
    if (!Greenfoot.isKeyDown("space")) { // pregunta si la tecla up esta levantada
            teclaPresionada_bala = false;
        }
    }   
    
           public boolean detener(){
     boolean isOnGround = true;
     //if (getY() > getWorld().getHeight()) isOnGround = false;
     int imageWidth = getImage().getWidth();
      int imageHeight = getImage().getHeight();
     if (getOneObjectAtOffset(imageWidth / -20, imageHeight / 2, Plataform.class) !=null ||getOneObjectAtOffset(imageWidth / 4, imageHeight / 4, Plataform.class) !=null)
     {
         isOnGround = false;
         numSaltos=0;
     }
   return isOnGround;
}
    
    public void act()
    {
        EventoTeclado();
        tamano();
        if (detener())gravedad();
        //if (getY() >= 265) { // Regresa al personaje a la posición inicial
          //   numSaltos=0;
             //setImage("inicial.png");  Cambia la imagen del personaje a la de su posición inicial
        
    }
}
