import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class alienD here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class alienD extends Actor
{
     public int disparosRecibidos = 0;
    int altura=250;
    int EnemyY=170;
    int hlanzada=0;//nuevo
    int  protaX;
   int protaY;
   int Xactual=400;//nuevo
   int cambio=0;//nuevo
   int direction=1;
    
    public void tamano() // tamano de un objeto en este caso el actor
    {
        GreenfootImage myImage = getImage();
        myImage.scale(100,150);
    }
    
    public void remove(){ // este metodo eliina al objeto de el mundo
        getWorld().removeObject(this);
    }
    public void act()
    {
        
        tamano();// Add your action code here.
        comportamiento();
        if(atWorldEdge())
        {
            move(-1);
        }
        Actor balaContact = getOneIntersectingObject(Bala.class); // confirma si hubo contacto con un objeto de la clase bala
        // con el if preguntamos si hubo contacto y en caso de que si entra al if
        if(balaContact!=null){
            Bala balas = (Bala) getWorld().getObjects(Bala.class).get(0);

            disparosRecibidos = disparosRecibidos+balas.dano();
            getWorld().removeObject(balaContact); // al hacer contacto se remueve la bala de el escenario
             // el contador de disparos recibidos aumenta  
            if(disparosRecibidos==8){ // si los disparos recibidos son 3 entonces removemos el enemigo 
            getWorld().removeObject(this);
            }
            }
    }
    

    public void cambioDireccion(){
        //cambia el comportamiento del achero si llega al limete de la barra
         if(Xactual==300)
        {
            direction=1;//avanza derecha
        setLocation(getX()+1,altura);
             //setImage("aCHERO.png");
        }
        
        if(Xactual==500){
            direction=-1;//leag al borde de la barra ahora a la izquierda
            //setLocation(getX()-1,altura);
             setLocation(getX()-1,altura);
              
        }
        
        
        Xactual=getX();//actualizamos la x
    }
      public void comportamiento(){
            int numero=Greenfoot.getRandomNumber(100);
            
                        if(numero>20&&numero<40){
                            move(2);
                        }
                        if(numero==69){
                            balaD balad2 = new balaD();
                            balad2.tamano();
                            balad2.setRotation(25);
                            getWorld().addObject(balad2, getX()-10, getY());
                        }
                        if(numero==80){
                            setImage("SSN_AD.png");
                            tamano();
                            BalaE balad23 = new BalaE();
                            balad23.tamano();
                            getWorld().addObject(balad23, getX()+10, getY());
                        }
                        
                        if(numero>40&&numero<60){
                            move(-2);
                            //setImage("alien_spin_inv.png");
                            //tamano();
                        }
                        if(numero==60){
                           
                            setImage("alien_spin_inv.png");
                            tamano();
                        }

      }
      
    
    public boolean atWorldEdge()
             
    {  
        if(getX() < 10 || getX() > getWorld().getWidth() - 20)  
            return true;  
        if(getY() < 10 || getY() > getWorld().getHeight() - 20)  
            return true;  
        else 
            return false;  
    } 
}
