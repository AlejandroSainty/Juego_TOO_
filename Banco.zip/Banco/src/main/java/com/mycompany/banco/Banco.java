/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banco;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;

/**
 *
 * @author Adriana
 */
public class Banco {

    public static void main(String[] args) throws ClassNotFoundException, InvocationTargetException {
        LinkedList<Object> lista =new LinkedList();
        Cuenta debito =new Cuenta(100,1,7);
        CuentaCredito credit=new CuentaCredito(0,117,7,16400,7);
        CuentaInversion inv =new CuentaInversion(0,119,7,1,5000);
       Contado cont =new Contado();
        lista.add(debito);
       lista.add(credit);
       lista.add(inv);
       lista.add(cont);
       try{
           for(Object o : lista)
       {
           Method m =o.getClass().getMethod("DameSaldo");
           System.out.println(m.invoke(o));
       }
       }catch(IllegalAccessException ex)
       {
           System.out.println(ex.toString());
       }catch(NoSuchMethodException  ex)
       {
           System.out.println(ex.toString());
       }catch(InvocationTargetException ex)
       {
           System.out.println(ex.toString());
       }
       
    }
}
