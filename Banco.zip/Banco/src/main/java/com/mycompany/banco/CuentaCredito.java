/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

import java.util.LinkedList;

public class CuentaCredito extends Cuenta {
    private int limite;
    private double taza;
      
    public CuentaCredito()
    {
        super();
        this.limite=0;
    }
      public CuentaCredito(float saldo,int numCuenta,int numCliente,int limite,double taza)
    {
       super(saldo,numCuenta,numCliente);
        this.limite=limite;
        this.taza=taza;
    }
      public float AbonarSaldo(float cantidad)
      {
          saldo=saldo-cantidad;
          return saldo;
      }
      
      public boolean CargoCuenta(double cantidad)
      {
          if((saldo+cantidad)<=limite)
          {
              saldo+=cantidad;
              return true;
          }
          return false;
      }
    
}
