/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

import java.util.LinkedList;


public class Cuenta {
    protected float saldo;
    protected int numeroDeCuenta;
    protected int numeroDeCliente;
    protected LinkedList<Periodo>p;
    
    public Cuenta()
    {
        this.saldo=0;
        this.numeroDeCuenta=0;
        this.numeroDeCliente=0;
        this.p=new LinkedList<Periodo>();
    }
    
    public Cuenta(float saldo,int numCuenta,int numCliente)
    {
        this.saldo=saldo;
        this.numeroDeCliente=numCliente;
        this.numeroDeCuenta=numCuenta;
        this.p=new LinkedList<Periodo>();
    }
    public boolean RestarSaldo(float cantidad)
    {
        if(saldo>=cantidad)
        {
            saldo-=cantidad;
            return true;
        }
        return false;
    }
    public double AbonaSaldo(float cantidad)
    {
        saldo=saldo+cantidad;
        return saldo;
    }
    public double DameSaldo()
    {
        return saldo;
    }
}
