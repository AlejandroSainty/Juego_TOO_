
package com.mycompany.banco;
import java.util.LinkedList;

public class CuentaInversion extends Cuenta{
        private int nivel;
    private int monto_min;
       public CuentaInversion()
    {
        super();
        this.nivel=1;
        this.monto_min=5000;
    }
       public CuentaInversion(float saldo,int numCuenta,int numCliente,int nivel,int montoM)
    {
       super(saldo,numCuenta,numCliente);
        this.nivel=nivel;
        this.monto_min=montoM;
    }
       public boolean AbonarSaldo(float cantidad,int nivel)
      {
          
          
              if(nivel==1)
              {
                 if(saldo<=monto_min)
                 {
                      if(saldo+cantidad<=monto_min)
              {
                 saldo=saldo+cantidad;
        return true; 
              }
                 }else
                 {
                   return false;  
                 } 
              }else{
                      monto_min=10000;
                  if(saldo<=monto_min)
                 {
                      if(saldo+cantidad<=monto_min)
              {
                 saldo=saldo+cantidad;
        return true; 
              }
                 }else
                 {
                   return false;  
                 }
                 }
            return false;
                 
          
            
      }
       
       public boolean CargoCuentaInversion(double cantidad,int fecha)
      {
          if(fecha==1)
          {
              saldo-=cantidad;
              return true;
          }
          return false;
      }
       public double GanaciaInversion(int nivel)
       {
           saldo=saldo*10+saldo;
        return saldo;
       }
}
